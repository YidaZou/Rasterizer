# A1 - Rasterizer
Yida Zou
760004766
yida.zou@tamu.edu

I've completed all taks up to and including task 7.

This is the site I used for the barycentric coordinate equations:
https://codeplea.com/triangular-interpolation

